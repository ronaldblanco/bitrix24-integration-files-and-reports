<?php
//define('C_REST_CLIENT_ID','local.5ee13cfa449a42.76061591');//Application ID
//define('C_REST_CLIENT_SECRET','6FC9l6VgrSRx6Ce4mwRWvumjWlvJ4kBpqH26v0LhZF92zCtnDO');//Application key
// or
define('C_REST_WEB_HOOK_URL','https://crm.305plasticsurgery.com/rest/1/23odl51wmxp7ea4p/');//url on creat Webhook

//define('C_REST_CURRENT_ENCODING','windows-1251');
//define('C_REST_IGNORE_SSL',true);//turn off validate ssl by curl
define('C_REST_LOG_TYPE_DUMP',false); //logs save var_export for viewing convenience
define('C_REST_BLOCK_LOG',false);//turn off default logs
//define('C_REST_LOGS_DIR', __DIR__ .'/logs/'); //directory path to save the log